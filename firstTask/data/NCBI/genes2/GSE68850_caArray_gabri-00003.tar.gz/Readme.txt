==================== Experiment Details ====================
*Experiment Name: TCGA Analysis of RNA Expression for Glioblastoma Multiforme

*Experiment Description: TCGA Analysis of RNA Expression for Glioblastoma Multiforme Using Affymetrix HT_HG-U133A

*Experiment Identifier: gabri-00003

*Assay Type: Gene Expression

*Provider: Affymetrix

*Array Designs: HT_HG-U133A

*Organism: Homo sapiens (ncbitax)

*Tissue Sites: Brain

*Material Types: synthetic_RNA, organism_part, solid_tumor, total_RNA, cell

*Cell Types: 

*Disease States: GLIOBLASTOMA MULTIFORME, NOT SPECIFIED


==================== Included Files ====================

*Experiment Filename: caArray_gabri-00003.zip

*MAGE-TAB (IDF and SDRF) files: gabri-00003_magetab_export.zip

Experiment file include both imported and exported MAGE-TAB files. In some cases data was submitted in several batches and the folder includes several imported IDF and  SDRF files. There is only one exported IDF and one exported SDRF file in the folder, the word "export" is incorporated in the exported MAGE-TAB file name.
